export enum ParticleShape {
  CIRCLE = 'Circle',
  SQUARE = 'Square',
  STAR = 'Star',
  SNOWFLAKE = 'Snowflake',
  PETAL = 'Petal'
}

export interface ParticleConfig {
  color: string;
  shape: ParticleShape;
  count: number;
  baseSpeed: number;
  baseSize: number;
}

export interface VisionState {
  isHandDetected: boolean;
  isOpen: boolean; // true = open hand, false = closed/pinch
  openness: number; // 0.0 to 1.0
}

// Global JSX augmentation for React Three Fiber elements
declare global {
  namespace JSX {
    interface IntrinsicElements {
      points: any;
      bufferGeometry: any;
      bufferAttribute: any;
      pointsMaterial: any;
      ambientLight: any;
      pointLight: any;
      color: any;
    }
  }
}