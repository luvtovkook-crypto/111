import React, { useState, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment } from '@react-three/drei';
import ParticleSystem from './components/ParticleSystem';
import Controls from './components/Controls';
import VisionController from './components/VisionController';
import { ParticleConfig, ParticleShape, VisionState } from './types';
import { generateThemeFromPrompt } from './services/geminiService';

const INITIAL_CONFIG: ParticleConfig = {
  color: '#00ffff',
  shape: ParticleShape.CIRCLE,
  count: 3000,
  baseSpeed: 0.5,
  baseSize: 0.15
};

const App: React.FC = () => {
  const [config, setConfig] = useState<ParticleConfig>(INITIAL_CONFIG);
  const [isGenerating, setIsGenerating] = useState(false);
  const [visionState, setVisionState] = useState<VisionState>({
    isHandDetected: false,
    isOpen: true,
    openness: 0
  });

  const handleVisionUpdate = (state: { detected: boolean; openness: number }) => {
    setVisionState(prev => ({
        ...prev,
        isHandDetected: state.detected,
        openness: state.openness,
        isOpen: state.openness > 0.5
    }));
  };

  const handleGenerateTheme = async (prompt: string) => {
    setIsGenerating(true);
    const result = await generateThemeFromPrompt(prompt);
    if (result) {
      setConfig(prev => ({ ...prev, ...result }));
    }
    setIsGenerating(false);
  };

  return (
    <div className="relative w-full h-screen bg-black">
      {/* 3D Scene */}
      <div className="absolute inset-0">
        <Canvas camera={{ position: [0, 0, 10], fov: 60 }} gl={{ antialias: false }}>
          <color attach="background" args={['#050505']} />
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} color={config.color} />
          
          <Suspense fallback={null}>
             <ParticleSystem 
                config={config} 
                handOpenness={visionState.openness} 
                isHandDetected={visionState.isHandDetected}
             />
             <Environment preset="city" />
          </Suspense>
          
          <OrbitControls 
            enableZoom={true} 
            enablePan={false} 
            rotateSpeed={0.5} 
            autoRotate={!visionState.isHandDetected}
            autoRotateSpeed={0.5}
          />
        </Canvas>
      </div>

      {/* UI Overlay */}
      <Controls 
        config={config}
        onConfigChange={setConfig}
        onGenerateTheme={handleGenerateTheme}
        isGenerating={isGenerating}
        visionState={{ detected: visionState.isHandDetected, openness: visionState.openness }}
      />

      {/* Computer Vision Module (Hidden/Minimial) */}
      <VisionController onUpdate={handleVisionUpdate} />
    </div>
  );
};

export default App;
