import { GoogleGenAI, Type } from "@google/genai";
import { ParticleShape, ParticleConfig } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateThemeFromPrompt = async (userPrompt: string): Promise<Partial<ParticleConfig> | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a particle system configuration based on this mood/theme: "${userPrompt}". 
      Return a JSON object with a color (hex code), a suitable shape (one of: Circle, Square, Star, Snowflake, Petal), 
      a particle count (between 1000 and 10000), a base speed (0.1 to 2.0), and a base size (0.05 to 0.5).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            color: { type: Type.STRING, description: "Hex color code, e.g. #FF0000" },
            shape: { type: Type.STRING, enum: Object.values(ParticleShape) },
            count: { type: Type.INTEGER },
            baseSpeed: { type: Type.NUMBER },
            baseSize: { type: Type.NUMBER }
          },
          required: ["color", "shape", "count", "baseSpeed", "baseSize"]
        }
      }
    });

    const text = response.text;
    if (!text) return null;
    
    return JSON.parse(text) as Partial<ParticleConfig>;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};
