import React, { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { ParticleConfig, ParticleShape } from '../types';

interface ParticleSystemProps {
  config: ParticleConfig;
  handOpenness: number; // 0 to 1
  isHandDetected: boolean;
}

const ParticleSystem: React.FC<ParticleSystemProps> = ({ config, handOpenness, isHandDetected }) => {
  const pointsRef = useRef<THREE.Points>(null);
  
  // Create geometry buffers
  const { positions, velocities, randoms } = useMemo(() => {
    const count = config.count;
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    const randoms = new Float32Array(count); // For varied movement

    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const radius = 2 + Math.random() * 3;

      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);

      velocities[i * 3] = (Math.random() - 0.5) * 0.02;
      velocities[i * 3 + 1] = (Math.random() - 0.5) * 0.02;
      velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.02;
      
      randoms[i] = Math.random();
    }
    return { positions, velocities, randoms };
  }, [config.count]);

  // Create Texture/Sprite based on Shape
  const texture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.fillStyle = '#FFFFFF';
    const cx = 32, cy = 32, r = 28;

    switch (config.shape) {
      case ParticleShape.SQUARE:
        ctx.fillRect(4, 4, 56, 56);
        break;
      case ParticleShape.STAR:
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
            ctx.lineTo(Math.cos((18 + i * 72) * 0.0174532925) * r + cx, -Math.sin((18 + i * 72) * 0.0174532925) * r + cy);
            ctx.lineTo(Math.cos((54 + i * 72) * 0.0174532925) * (r/2) + cx, -Math.sin((54 + i * 72) * 0.0174532925) * (r/2) + cy);
        }
        ctx.closePath();
        ctx.fill();
        break;
      case ParticleShape.PETAL:
        ctx.beginPath();
        ctx.ellipse(cx, cy, r, r/3, Math.PI/4, 0, 2 * Math.PI);
        ctx.fill();
        break;
      case ParticleShape.SNOWFLAKE:
         ctx.strokeStyle = '#FFFFFF';
         ctx.lineWidth = 4;
         ctx.translate(cx, cy);
         for(let i=0; i<6; i++) {
           ctx.beginPath();
           ctx.moveTo(0,0);
           ctx.lineTo(0, r);
           ctx.moveTo(0, r * 0.5);
           ctx.lineTo(r*0.3, r*0.7);
           ctx.moveTo(0, r * 0.5);
           ctx.lineTo(-r*0.3, r*0.7);
           ctx.stroke();
           ctx.rotate(Math.PI / 3);
         }
        break;
      case ParticleShape.CIRCLE:
      default:
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    return tex;
  }, [config.shape]);

  useFrame((state) => {
    if (!pointsRef.current) return;
    
    // Smoothness factor for transitioning
    const targetSpeed = isHandDetected 
      ? (handOpenness * 2.5 + 0.1) * config.baseSpeed // Open hand = fast
      : config.baseSpeed * 0.2; // Idle speed

    const targetSpread = isHandDetected
      ? (handOpenness * 5 + 1.5) // Open hand = wide spread
      : 2.0; // Idle spread

    const positionsArr = pointsRef.current.geometry.attributes.position.array as Float32Array;
    
    const time = state.clock.getElapsedTime();

    for (let i = 0; i < config.count; i++) {
      const ix = i * 3;
      const iy = i * 3 + 1;
      const iz = i * 3 + 2;

      // Base movement
      positionsArr[ix] += velocities[ix] * (1 + targetSpeed * 5);
      positionsArr[iy] += velocities[iy] * (1 + targetSpeed * 5);
      positionsArr[iz] += velocities[iz] * (1 + targetSpeed * 5);

      // Attraction/Repulsion logic based on spread
      // Calculate current distance from center
      const x = positionsArr[ix];
      const y = positionsArr[iy];
      const z = positionsArr[iz];
      const distSq = x*x + y*y + z*z;
      const dist = Math.sqrt(distSq);

      // Force particles towards target spread radius
      // We add some noise based on time and randoms to make it organic
      if (dist > 0.1) {
         const force = (targetSpread - dist) * 0.05; // Spring force
         positionsArr[ix] += (x / dist) * force;
         positionsArr[iy] += (y / dist) * force;
         positionsArr[iz] += (z / dist) * force;
      }
      
      // Rotation effect
      const rotSpeed = 0.001 * targetSpeed;
      const oldX = positionsArr[ix];
      const oldZ = positionsArr[iz];
      positionsArr[ix] = oldX * Math.cos(rotSpeed) - oldZ * Math.sin(rotSpeed);
      positionsArr[iz] = oldX * Math.sin(rotSpeed) + oldZ * Math.cos(rotSpeed);
    }

    pointsRef.current.geometry.attributes.position.needsUpdate = true;
    
    // Pulse scale based on hand openness
    if (pointsRef.current.material instanceof THREE.PointsMaterial) {
       pointsRef.current.material.size = config.baseSize * (1 + handOpenness * 0.5);
       pointsRef.current.rotation.z += 0.001;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        attach="material"
        map={texture || undefined}
        size={config.baseSize}
        color={config.color}
        transparent
        opacity={0.8}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

export default ParticleSystem;
