import React, { useEffect, useRef, useState } from 'react';
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';

interface VisionControllerProps {
  onUpdate: (state: { detected: boolean; openness: number }) => void;
}

const VisionController: React.FC<VisionControllerProps> = ({ onUpdate }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [loading, setLoading] = useState(true);
  const landmarkerRef = useRef<HandLandmarker | null>(null);
  const requestRef = useRef<number | null>(null);

  useEffect(() => {
    let mounted = true;

    const setupVision = async () => {
      try {
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm"
        );
        
        if (!mounted) return;

        const landmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
            delegate: "GPU"
          },
          runningMode: "VIDEO",
          numHands: 1
        });

        if (!mounted) return;
        landmarkerRef.current = landmarker;
        setLoading(false);
        startCamera();
      } catch (err) {
        console.error("Failed to load MediaPipe", err);
        setLoading(false);
      }
    };

    setupVision();

    return () => {
      mounted = false;
      if (landmarkerRef.current) landmarkerRef.current.close();
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const startCamera = async () => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { width: 320, height: 240, facingMode: "user" } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.addEventListener("loadeddata", predictWebcam);
        }
      } catch (err) {
        console.error("Camera access denied", err);
      }
    }
  };

  const predictWebcam = () => {
    const video = videoRef.current;
    const landmarker = landmarkerRef.current;

    if (video && landmarker && video.videoWidth > 0) {
      const startTimeMs = performance.now();
      const results = landmarker.detectForVideo(video, startTimeMs);

      if (results.landmarks && results.landmarks.length > 0) {
        // Calculate openness
        const landmarks = results.landmarks[0];
        const thumbTip = landmarks[4];
        const indexTip = landmarks[8];
        const wrist = landmarks[0];
        const middleMCP = landmarks[9];

        // Normalization scale: approximate hand size (wrist to middle finger base)
        const scale = Math.sqrt(
            Math.pow(middleMCP.x - wrist.x, 2) + 
            Math.pow(middleMCP.y - wrist.y, 2)
        );

        // Distance between thumb and index
        const pinchDist = Math.sqrt(
            Math.pow(thumbTip.x - indexTip.x, 2) + 
            Math.pow(thumbTip.y - indexTip.y, 2)
        );

        // Normalized Openness (approximate thresholds)
        // 0.3 scale is roughly a very open pinch
        // 0.05 scale is a closed pinch
        let openness = (pinchDist / scale);
        // Clamp and map 0.1->0.8 to 0->1
        openness = Math.max(0, Math.min(1, (openness - 0.2) * 2.0));

        onUpdate({ detected: true, openness });
      } else {
        onUpdate({ detected: false, openness: 0 });
      }
    }
    requestRef.current = requestAnimationFrame(predictWebcam);
  };

  return (
    <div className="absolute bottom-4 right-4 z-50 overflow-hidden rounded-lg border border-white/20 shadow-lg bg-black/80 w-32 h-24 transition-opacity duration-300">
        {/* Hidden but functional video element */}
        <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted
            className="w-full h-full object-cover opacity-50 transform scale-x-[-1]" 
        />
        {loading && (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-white">
                Loading AI...
            </div>
        )}
        <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-[10px] text-center text-white p-1">
            Camera Feed
        </div>
    </div>
  );
};

export default VisionController;