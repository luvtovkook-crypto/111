import React, { useState } from 'react';
import { ParticleConfig, ParticleShape } from '../types';
import { Sliders, Maximize2, Sparkles, Loader2, Hand } from 'lucide-react';

interface ControlsProps {
  config: ParticleConfig;
  onConfigChange: (newConfig: ParticleConfig) => void;
  onGenerateTheme: (prompt: string) => Promise<void>;
  isGenerating: boolean;
  visionState: { detected: boolean; openness: number };
}

const Controls: React.FC<ControlsProps> = ({ 
  config, 
  onConfigChange, 
  onGenerateTheme, 
  isGenerating,
  visionState
}) => {
  const [prompt, setPrompt] = useState('');
  const [isOpen, setIsOpen] = useState(true);

  const handleShapeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onConfigChange({ ...config, shape: e.target.value as ParticleShape });
  };

  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onConfigChange({ ...config, color: e.target.value });
  };

  const handlePromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onGenerateTheme(prompt);
      setPrompt('');
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="absolute top-4 left-4 z-40 p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-all border border-white/10"
      >
        <Sliders size={20} />
      </button>
    );
  }

  return (
    <div className="absolute top-4 left-4 z-40 w-80 bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 text-white shadow-2xl transition-all animate-in fade-in slide-in-from-left duration-500">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          Gesture Particles
        </h1>
        <div className="flex gap-2">
            <button 
                onClick={toggleFullscreen}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                title="Fullscreen"
            >
                <Maximize2 size={16} />
            </button>
            <button 
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors text-white/50 hover:text-white"
            >
                <Sliders size={16} />
            </button>
        </div>
      </div>

      {/* Vision Status Indicator */}
      <div className="mb-6 p-3 rounded-xl bg-white/5 border border-white/5 flex items-center gap-3">
         <div className={`w-2 h-2 rounded-full ${visionState.detected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
         <div className="flex-1">
             <p className="text-xs text-white/60 uppercase tracking-wider font-semibold">
                {visionState.detected ? 'Hand Detected' : 'No Hand Detected'}
             </p>
             {visionState.detected && (
                 <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
                     <div 
                        className="h-full bg-blue-500 transition-all duration-100 ease-out"
                        style={{ width: `${visionState.openness * 100}%` }}
                     />
                 </div>
             )}
         </div>
         <Hand className={`text-white/40 ${visionState.detected ? 'text-blue-400' : ''}`} size={16} />
      </div>

      <div className="space-y-5">
        {/* Manual Controls */}
        <div>
          <label className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-2 block">Shape</label>
          <div className="relative">
             <select 
                value={config.shape}
                onChange={handleShapeChange}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/50 text-sm"
            >
                {Object.values(ParticleShape).map(s => (
                <option key={s} value={s} className="bg-gray-900">{s}</option>
                ))}
            </select>
          </div>
        </div>

        <div>
            <label className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-2 block">Color</label>
            <div className="flex gap-3 items-center">
                <input 
                    type="color" 
                    value={config.color}
                    onChange={handleColorChange}
                    className="h-8 w-12 rounded cursor-pointer bg-transparent border-none"
                />
                <span className="text-sm font-mono text-white/80">{config.color}</span>
            </div>
        </div>

        {/* AI Generator */}
        <div className="pt-4 border-t border-white/10">
           <label className="text-xs font-semibold text-blue-400/80 uppercase tracking-wider mb-2 flex items-center gap-2">
             <Sparkles size={12} />
             Gemini Theme Generator
           </label>
           <form onSubmit={handlePromptSubmit} className="relative">
             <input 
               type="text" 
               value={prompt}
               onChange={(e) => setPrompt(e.target.value)}
               placeholder="e.g. 'Cyberpunk Rain' or 'Cherry Blossom'"
               className="w-full bg-white/5 border border-white/10 rounded-lg pl-4 pr-10 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 placeholder-white/20"
               disabled={isGenerating}
             />
             <button 
                type="submit" 
                disabled={isGenerating}
                className="absolute right-1 top-1 p-1.5 bg-blue-600 hover:bg-blue-500 rounded-md text-white disabled:opacity-50 transition-colors"
             >
                {isGenerating ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
             </button>
           </form>
        </div>
      </div>
      
      <div className="mt-6 text-[10px] text-white/30 text-center">
        Powered by Gemini 2.5 Flash & MediaPipe
      </div>
    </div>
  );
};

export default Controls;
